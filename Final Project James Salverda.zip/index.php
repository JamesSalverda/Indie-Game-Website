<?php

    header("Location: homePage.php");
    exit;

?>